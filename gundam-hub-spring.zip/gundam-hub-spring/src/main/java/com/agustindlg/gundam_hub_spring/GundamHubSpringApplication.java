package com.agustindlg.gundam_hub_spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GundamHubSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(GundamHubSpringApplication.class, args);
	}

}
