package com.agustindlg.gundam_hub_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GundamHubSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
